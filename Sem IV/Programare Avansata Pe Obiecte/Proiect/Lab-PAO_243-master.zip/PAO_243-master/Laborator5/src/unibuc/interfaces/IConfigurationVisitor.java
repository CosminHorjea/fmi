package unibuc.interfaces;

public interface IConfigurationVisitor {
    void visit(String key, Object value);
}
