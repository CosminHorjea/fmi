package unibuc.interfaces;

public interface ISerializable {
}
