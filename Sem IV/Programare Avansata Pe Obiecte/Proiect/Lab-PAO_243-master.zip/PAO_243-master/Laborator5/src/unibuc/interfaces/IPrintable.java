package unibuc.interfaces;

public interface IPrintable {
    void print();
}
