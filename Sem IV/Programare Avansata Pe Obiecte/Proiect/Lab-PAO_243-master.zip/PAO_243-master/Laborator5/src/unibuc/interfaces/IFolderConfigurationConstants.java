package unibuc.interfaces;

public interface IFolderConfigurationConstants {
    String ROOT = "folder.root";
    String FILTER = "folder.filter";
}
