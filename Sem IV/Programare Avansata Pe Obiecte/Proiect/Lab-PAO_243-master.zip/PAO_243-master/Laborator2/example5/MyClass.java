package unibuc.example5;

public class MyClass {
    int a;
    static int b;
    final String c = "This is final";
}
