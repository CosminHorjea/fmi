package unibuc.example4;

public class Example4 {
    public static void main(String[] args) {
        Student s = new Student();
        System.out.println(s.getAge());
        System.out.println(s.getGroup());
        System.out.println(s.isPresent());
        System.out.println(s.getGraduated());
    }
}
