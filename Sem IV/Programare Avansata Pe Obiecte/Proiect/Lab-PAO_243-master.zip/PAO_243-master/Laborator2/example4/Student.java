package unibuc.example4;

public class Student {
    private int age;
    private Integer group;
    private boolean present;
    private Boolean graduated;

    public int getAge() {
        return age;
    }

    public Integer getGroup() {
        return group;
    }

    public boolean isPresent() {
        return present;
    }

    public Boolean getGraduated() {
        return graduated;
    }
}
