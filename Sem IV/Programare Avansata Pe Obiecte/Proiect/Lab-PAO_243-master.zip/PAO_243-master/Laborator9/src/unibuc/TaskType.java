package unibuc;

public enum TaskType {
    USER_STORY, BUG, IMPROVEMENT, EPIC
}
