package unibuc;

public enum Priority {
    HIGH, LOW, MEDIUM, TRIVIAL, CRITICAL
}
