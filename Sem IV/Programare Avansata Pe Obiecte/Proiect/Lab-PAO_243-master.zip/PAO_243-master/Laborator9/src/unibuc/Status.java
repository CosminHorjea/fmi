package unibuc;

public enum Status {
    RESOLVED, OPEN, CLOSED, IN_PROGRESS
}
