package unibuc;

public class Example4 {
    public static void main(String[] args) {
        int a = 4, b = 67;
        System.out.println(a != b);
        System.out.println(a == b);
    }
}
