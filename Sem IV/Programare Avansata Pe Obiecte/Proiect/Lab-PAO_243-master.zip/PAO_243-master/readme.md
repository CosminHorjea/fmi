# PAO labs 2021 (grupa 243)

LABORATOR PAO 

#### Punctaj
- 50% examen final
- 50% laborator (proiect - 3 etape)
- conditie promovare: obtinere 50% punctajul aferent examenului si 50% din punctajul aferent proiectului


###### Contact
Silvia Ilie-Nemedi

silvia.ilie@endava.com 

silvia.nemedi@unibuc.ro
