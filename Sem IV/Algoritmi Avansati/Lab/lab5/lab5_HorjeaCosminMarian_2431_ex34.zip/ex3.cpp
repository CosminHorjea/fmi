#include <bits/stdc++.h>

using namespace std;

typedef pair<double, double> point;

ifstream f("ex3.in");
map<point, char> labels;
double testTurn(point p, point q, point r)
{
  double a = q.first * r.second;
  a += p.second * r.first;
  a += p.first * q.second;
  a -= q.first * p.second;
  a -= p.first * r.second;
  a -= q.second * r.first;
  return a;
}

ostream &operator<<(ostream &out, point x)
{
  out << labels[x] << " " << x.first << " " << x.second << endl;
  return out;
}

int main()
{
  vector<point> points;
  vector<point> result;
  char label = 'A';
  double x, y;
  while (f >> x >> y)
  {
    points.push_back(make_pair(x, y));
    labels[make_pair(x, y)] = label++; // asociez un label intr-un map pentru afisare
  }
  point pointToTest;
  cout << "Introduceti coordoatele punctului\n";
  cin >> pointToTest.first;
  cin >> pointToTest.second;
  int s = 1;
  int d = points.size() - 1;
  while (s < d - 1)
  {
    int m = (s + d) / 2;
    double rotation = testTurn(points[0], points[m], pointToTest);
    if (rotation > 0)
    {
      s = m;
    }
    else
    {
      d = m;
    }
  }
  // cout << "Ultimele doua puncte care formeaza triunghiul\n"; //!DEBUG
  // cout << points[s] << points[d];
  //verificam daca punctul este in triunghi
  if (testTurn(points[d], points[s], pointToTest) <= 0 &&
      testTurn(points[0], points[d], pointToTest) <= 0 &&
      testTurn(points[s], points[0], pointToTest) <= 0)
  {
    cout << "In interior";
  }
  else
  {
    cout << "Afara";
  }
}
// * https://www.geogebra.org/calculator/xhjdvn7a
// * teste
// -0.56 5.03 : In interior
// 2.05 -1.61 : In interior
// 5    -3    : Afara
