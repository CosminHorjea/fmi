#include <bits/stdc++.h>

using namespace std;

typedef pair<double, double> point;

const double inf = 1e5 + 5;

ifstream f("ex4.in");
map<point, char> labels;
double testTurn(point p, point q, point r)
{
  double a = q.first * r.second;
  a += p.second * r.first;
  a += p.first * q.second;
  a -= q.first * p.second;
  a -= p.first * r.second;
  a -= q.second * r.first;
  return a;
}

double distance(point p1, point p2)
{
  return sqrt(abs(p2.first - p1.first) + abs(p2.second - p1.second));
}

ostream &operator<<(ostream &out, point x)
{
  out << labels[x] << " " << x.first << " " << x.second << endl;
  return out;
}

//pentru a afla punctele care formeaza acoperirea
vector<point> jarvis(vector<point> &points)
{
  vector<point> result;
  point pointOnHull = points[0];
  int i = 0;
  point endpoint = points[0];
  do
  {
    result.push_back(pointOnHull);
    endpoint = points[0];
    for (int j = 0; j < points.size(); j++)
    {
      if ((endpoint == pointOnHull) || (testTurn(result[i], endpoint, points[j]) > 0))
      {
        endpoint = points[j];
      }
    }
    i++;
    pointOnHull = endpoint;
  } while (endpoint != result[0]);

  return result;
}

vector<point> tspFromHull(vector<point> &hull, vector<point> &points)
{
  // implementarea este preluata de aici
  // https://www2.isye.gatech.edu/~mgoetsch/cali/VEHICLE/TSP/TSP017__.HTM

  //desen folosit pentru input
  // http://prntscr.com/11zuqxi
  set<point> notInSubTour;
  vector<point> copyHull = hull;
  sort(copyHull.begin(), copyHull.end());
  set_difference(points.begin(), points.end(), copyHull.begin(), copyHull.end(), std::inserter(notInSubTour, notInSubTour.begin())); //adaug punctele care nu sunt in acoperire
  while (!notInSubTour.empty())                                                                                                      //cat timp am puncte de adaugat
  {
    vector<vector<point>> pairs;
    for (point r : notInSubTour)
    {
      double minCost = inf;
      point pointi, pointj;
      for (int indexI = 0; indexI < hull.size(); indexI++)
      {
        point i = hull[indexI];
        point j = hull[(indexI + 1) % hull.size()]; // iau punctele i si j care au o muchie intre ele in acoperire, adica care se alfa pe pozitii consecutive
        if (minCost > distance(i, r) + distance(r, j) - distance(i, j))
        {
          minCost = distance(i, r) + distance(r, j) - distance(i, j);
          pointi = i;
          pointj = j;
        }
      }
      pairs.push_back({pointi, pointj, r}); // salvez perechea cea mai buna pentru punctul curent
    }
    double minCost = inf;
    point pointi, pointj, pointr;
    for (auto p : pairs) //aleg cea mai buna pereche (i*,j*,r*)
    {
      point i = p[0];
      point j = p[1];
      point r = p[2];
      if (minCost > (distance(i, r) + distance(r, j) / distance(i, j)))
      {
        minCost = (distance(i, r) + distance(r, j) / distance(i, j));
        pointi = i;
        pointj = j;
        pointr = r;
      }
    }
    for (int i = 0; i < hull.size(); i++) //adaug in acoperire
    {
      if (hull[i] == pointi)
      {
        hull.insert(hull.begin() + i + 1, pointr);
        break;
      }
    }
    notInSubTour.erase(pointr); // il scot din setul de puncte nefolosite
    // cout << "i: " << pointi << "j: " << pointj << "r: " << pointr; // !DEBUG
    // for (auto p : hull)
    // {
    //   cout << p;
    // }
    // cout << "----------\n";
  }
  return hull;
}

int main()
{
  vector<point> points;
  vector<point> result;
  char label = 'A';
  double x, y;
  while (f >> x >> y)
  {
    points.push_back(make_pair(x, y));
    labels[make_pair(x, y)] = label++;
  }
  sort(points.begin(), points.end());
  vector<point> hull = jarvis(points);           //iau mai intai acoperirea
  vector<point> tsp = tspFromHull(hull, points); //dupa iau traseul
  for (auto p : tsp)
  {
    cout << p;
  }
}