#include <bits/stdc++.h>

using namespace std;

typedef pair<double, double> point;

ifstream f("ex2.in");

double testTurn(point p, point q, point r)
{
  double a = q.first * r.second;
  a += p.second * r.first;
  a += p.first * q.second;
  a -= q.first * p.second;
  a -= p.first * r.second;
  a -= q.second * r.first;
  return a;
}

int main()
{
  vector<point> points;
  vector<point> result;
  double x, y;
  while (f >> x >> y)
  {
    points.push_back(make_pair(x, y));
  }
  int x_max = points[0].first;
  for (int i = 1; i < points.size(); i++)
  {
    if (points[i].first > points[x_max].first)
      x_max = i; //iau pozitia puntului cu x-ul maxim, care stiu ca e in acoperire
  }
  while (x_max--) //rotesc vectorul astfel incat primul punct este in acoperire
  {
    points.push_back(*points.begin());
    points.erase(points.begin());
  }
  result.push_back(points[0]); // pun doua puncte in "stiva" de rezultate si le elimin din vectorul de puncte
  result.push_back(points[1]);
  points.erase(points.begin());
  points.erase(points.begin());
  for (point p : points) // pentru fiecare punct ramas
  {
    int currPoints = result.size();
    if (testTurn(result[currPoints - 2], result[currPoints - 1], p) <= 0) //verific virajul iar daca este la dreapta
    {
      result.pop_back(); //elimin punctul ultim adaugar
    }
    result.push_back(p); // adaug punctul curent
  }
  while (testTurn(result[result.size() - 2], result[result.size() - 1], result[0]) <= 0) //elimin punctele de la final care fac viraj la dreapta cu punctul initial
  {
    result.pop_back();
  }

  for (point p : result)
  {
    cout << p.first << " " << p.second << endl;
  }
}