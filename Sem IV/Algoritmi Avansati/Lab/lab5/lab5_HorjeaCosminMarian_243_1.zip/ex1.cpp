#include <bits/stdc++.h>

using namespace std;

typedef pair<double, double> point;

double testTurn(point p, point q, point r)
{
  double a = q.first * r.second;
  a += p.second * r.first;
  a += p.first * q.second;
  a -= q.first * p.second;
  a -= p.first * r.second;
  a -= q.second * r.first;
  return a;
}

int main()
{
  point a, b, c;
  cin >> a.first >> a.second;
  cin >> b.first >> b.second;
  cin >> c.first >> c.second;
  double res = testTurn(a, b, c);
  if (res < 0)
  {
    cout << "Viraj la dreapta";
  }
  else if (res == 0)
  {
    cout << "Puncte coliniare";
  }
  else
  {
    cout << "Viraj la stanga";
  }
  cout << endl;
}