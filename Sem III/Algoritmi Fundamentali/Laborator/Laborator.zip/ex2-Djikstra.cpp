#include <bits/stdc++.h>

using namespace std;

map<int, vector<int>> graf;
vector<vector<int>> cost;

int main()
{
  cout << "hello world";
  return 0;
}